"""
campaigns/views.py — KPN Newsroom views.

Public:
  newsroom          /campaigns/
  article_detail    /campaigns/<slug>/
  
Staff (writers - any approved leader):
  write_article     /campaigns/write/
  my_articles       /campaigns/my-articles/
  edit_article      /campaigns/edit/<id>/
  delete_article    /campaigns/delete/<id>/
  submit_for_review /campaigns/submit/<id>/
  image_upload      /campaigns/api/upload-image/  (Editor.js image tool)

Editors (Director of Media & Communications):
  review_queue      /campaigns/review/
  publish_article   /campaigns/publish/<id>/
  return_article    /campaigns/return/<id>/
"""
import json
import re

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.utils.text import slugify
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.db.models import Q

from .models import Campaign
from .forms import ArticleForm, CampaignForm
from staff.decorators import approved_leader_required, specific_role_required
from leadership.models import LGA, Ward

# Roles permitted to review and publish articles
EDITOR_ROLES = [
    'Director of Media & Communications',
    'Assistant Director of Media & Communications',
    'President',
    'General Secretary',
]


# ─── PUBLIC VIEWS ──────────────────────────────────────────────────────────────

def newsroom(request):
    """Public newsroom listing — filterable by search, category, LGA,
    verification status, publication date and provenance.

    Featured rule (Page-by-Page Upgrade D-09, documented selection
    rule — no manual flag): the latest VERIFIED story leads the page;
    if none in the current result set is VERIFIED, the latest story
    leads. DEVELOPING stories published in the last 48 hours carry the
    breaking/developing treatment."""
    from datetime import timedelta
    articles = Campaign.objects.filter(status='PUBLISHED').select_related(
        'author', 'lga', 'ward', 'approved_by'
    ).order_by('-published_at')

    category = request.GET.get('category', '')
    lga_id = request.GET.get('lga', '')
    verification = request.GET.get('status', '')
    search = request.GET.get('q', '').strip()
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    provenance = request.GET.get('source', '')

    if category:
        articles = articles.filter(category=category)
    if lga_id:
        articles = articles.filter(lga_id=lga_id)
    if verification:
        articles = articles.filter(verification_status=verification)
    if search:
        articles = articles.filter(
            Q(title__icontains=search) |
            Q(subheadline__icontains=search) |
            Q(location__icontains=search)
        )
    if date_from:
        articles = articles.filter(published_at__date__gte=date_from)
    if date_to:
        articles = articles.filter(published_at__date__lte=date_to)
    if provenance == 'community':
        # Stories with a recorded community-report source link
        # (story_intelligence StorySourceLink — linked records, §6).
        articles = articles.filter(source_links__isnull=False).distinct()

    results = list(articles[:13])
    featured = None
    for candidate in results:
        if candidate.verification_status == 'VERIFIED':
            featured = candidate
            break
    if featured is None and results:
        featured = results[0]
    rest = [a for a in results if featured is None or a.pk != featured.pk][:12]

    breaking = [
        a for a in results
        if a.verification_status == 'DEVELOPING'
        and a.published_at
        and a.published_at >= timezone.now() - timedelta(hours=48)
    ][:3]

    lgas = LGA.objects.all().order_by('name')

    context = {
        'articles': articles,
        'featured': featured,
        'rest': rest,
        'breaking': breaking,
        'lgas': lgas,
        'categories': Campaign.CATEGORY_CHOICES,
        'verification_choices': Campaign.VERIFICATION_STATUS_CHOICES,
        'active_category': category,
        'active_lga': lga_id,
        'active_verification': verification,
        'active_date_from': date_from,
        'active_date_to': date_to,
        'active_provenance': provenance,
        'search_query': search,
    }
    return render(request, 'campaigns/newsroom.html', context)


def article_detail(request, slug):
    """Public article detail page."""
    article = get_object_or_404(Campaign, slug=slug)

    # Security check: only show if published, OR if the current user is the author or a media director
    if article.status != 'PUBLISHED':
        is_author = request.user.is_authenticated and article.author == request.user
        is_editor = request.user.is_authenticated and request.user.is_leader()
        if not (is_author or is_editor):
            from django.http import Http404
            raise Http404("No published Campaign matches the given query.")

    # Increment view count (lightweight, non-atomic is fine here) - only if published to not inflate counts during preview
    if article.status == 'PUBLISHED':
        Campaign.objects.filter(pk=article.pk).update(views=article.views + 1)
        article.views += 1

    # Related articles — same category, exclude current
    related = Campaign.objects.filter(
        status='PUBLISHED', category=article.category
    ).exclude(pk=article.pk).order_by('-published_at')[:4]

    # KPN Media Phase 1: reader-safe story panel data (None when the
    # article has no story records — the page then renders as before).
    from story_intelligence.services import story_panel_context
    story_panel = story_panel_context(article) if article.status == 'PUBLISHED' else None

    from django.urls import reverse
    crumbs = [
        ('Newsroom', reverse('campaigns:newsroom')),
        (article.title if len(article.title) <= 60 else article.title[:57] + '…', None),
    ]
    context = {
        'article': article,
        'related': related,
        'story_panel': story_panel,
        'crumbs': crumbs,
    }
    return render(request, 'campaigns/article_detail.html', context)


# ─── WRITER VIEWS (any approved leader) ────────────────────────────────────────

@approved_leader_required
def write_article(request):
    """CMS editor — create a new article."""
    if request.method == 'POST':
        form = ArticleForm(request.POST, request.FILES)
        if form.is_valid():
            article = form.save(commit=False)
            article.author = request.user
            article.status = 'DRAFT'
            article.save()
            messages.success(request, 'Article saved as draft.')
            return redirect('campaigns:my_articles')
        else:
            messages.error(request, 'Please check the form for errors.')
    else:
        form = ArticleForm()

    return render(request, 'campaigns/write_article.html', {
        'form': form,
        'mode': 'create',
        'existing_content_json': '',
    })


def _is_editor(user):
    """Editors (Media Director, Assistant, President, General Secretary)
    manage every article, including published ones."""
    return getattr(user.role_definition, 'title', '') in EDITOR_ROLES


@approved_leader_required
def my_articles(request):
    """List articles the current user manages. Editors see all articles
    (they run the newsroom); other writers see only their own."""
    if _is_editor(request.user):
        articles = Campaign.objects.all().select_related('author').order_by('-updated_at')
    else:
        articles = Campaign.objects.filter(author=request.user).order_by('-updated_at')
    context = {'articles': articles, 'is_editor': _is_editor(request.user)}
    return render(request, 'campaigns/my_articles.html', context)


@approved_leader_required
def edit_article(request, article_id):
    """CMS editor — edit an existing article.

    Authors can edit their own drafts/returned articles. Editors can edit
    ANY article, including PUBLISHED ones, and a published article stays
    published after an editor saves it (owner request 2026-10-30: the
    Director of Media must be able to fix a live article himself)."""
    if _is_editor(request.user):
        article = get_object_or_404(Campaign, pk=article_id)
    else:
        article = get_object_or_404(Campaign, pk=article_id, author=request.user)
        if article.status == 'PUBLISHED':
            messages.error(request, 'Published articles cannot be edited. Contact the Media Director.')
            return redirect('campaigns:my_articles')
        if article.status == 'PENDING':
            messages.error(request, 'This article is in review and locked. Contact the Media Director.')
            return redirect('campaigns:my_articles')

    if request.method == 'POST':
        form = ArticleForm(request.POST, request.FILES, instance=article)
        if form.is_valid():
            previous_verification = article.verification_status
            updated = form.save(commit=False)
            # Reset status to DRAFT if it was REJECTED, so it goes back through review.
            # Editors editing a PUBLISHED article keep it PUBLISHED.
            if updated.status == 'REJECTED':
                updated.status = 'DRAFT'
                updated.rejection_note = ''
            updated.save()
            # Truth Layers: keep a history of verification-status changes.
            if updated.verification_status != previous_verification:
                from story_intelligence.services import record_verification_event
                record_verification_event(
                    updated, updated.verification_status, request.user,
                    old_value=previous_verification)
            messages.success(request, 'Article updated successfully.')
            return redirect('campaigns:my_articles')
        else:
            messages.error(request, 'Please check the form for errors.')
    else:
        form = ArticleForm(instance=article)

    # Pass existing Editor.js JSON as string for JavaScript to load
    existing_content_json = json.dumps(article.content_json) if article.content_json else ''

    return render(request, 'campaigns/write_article.html', {
        'form': form,
        'article': article,
        'existing_content_json': existing_content_json,
        'mode': 'edit',
    })


@approved_leader_required
def delete_article(request, article_id):
    """Delete an article. Authors: their own drafts/returned articles.
    Editors: any UNPROTECTED article. Since KPN Media Phase 1 (owner
    spec 2026-11-01, superseding the 2026-10-30 delete-anything rule for
    these records), published articles, articles with a Story ID and
    articles with story records cannot be hard-deleted — they are
    archived instead, preserving the permanent story record."""
    if _is_editor(request.user):
        article = get_object_or_404(Campaign, pk=article_id)
    else:
        article = get_object_or_404(Campaign, pk=article_id, author=request.user)
        if article.status in ['PUBLISHED', 'PENDING']:
            messages.error(request, 'Cannot delete a published or pending article.')
            return redirect('campaigns:my_articles')

    from .services import ProtectedArticleError, article_is_protected, delete_campaign
    if article_is_protected(article):
        messages.error(
            request,
            'This article is part of the permanent story archive and cannot '
            'be deleted. Archive it instead to remove it from public view.')
        return redirect('campaigns:my_articles')

    if request.method == 'POST':
        try:
            delete_campaign(article)
        except ProtectedArticleError as exc:
            messages.error(request, str(exc))
            return redirect('campaigns:my_articles')
        messages.success(request, 'Article deleted.')
        return redirect('campaigns:my_articles')

    return render(request, 'campaigns/delete_article.html', {'article': article})


@approved_leader_required
def archive_article(request, article_id):
    """Archive a published article: removed from public view, record,
    Story ID and story history preserved (KPN Media Phase 1)."""
    if _is_editor(request.user):
        article = get_object_or_404(Campaign, pk=article_id)
    else:
        article = get_object_or_404(Campaign, pk=article_id, author=request.user)

    if article.status != 'PUBLISHED':
        messages.error(request, 'Only published articles can be archived.')
        return redirect('campaigns:my_articles')

    if request.method == 'POST':
        from .services import archive_campaign
        archive_campaign(article, actor=request.user)
        messages.success(
            request,
            f'"{article.title}" has been archived. It is no longer public, '
            'but its record and Story ID are preserved.')
        return redirect('campaigns:my_articles')

    return render(request, 'campaigns/archive_article.html', {'article': article})


@approved_leader_required
def restore_article(request, article_id):
    """Restore an archived article to published, keeping its Story ID."""
    if _is_editor(request.user):
        article = get_object_or_404(Campaign, pk=article_id)
    else:
        article = get_object_or_404(Campaign, pk=article_id, author=request.user)

    if article.status != 'ARCHIVED':
        messages.error(request, 'Only archived articles can be restored.')
        return redirect('campaigns:my_articles')

    if request.method == 'POST':
        from .services import restore_campaign
        restore_campaign(article, actor=request.user)
        messages.success(request, f'"{article.title}" is published again.')
        return redirect('campaigns:my_articles')

    return render(request, 'campaigns/restore_article.html', {'article': article})


@approved_leader_required
def submit_for_review(request, article_id):
    """Submit a draft (or returned) article to the editorial review queue.

    Published and pending articles are NOT errors here (owner report
    2026-10-30: the edit page used to offer this action for a live
    article and then scold the editor). A published article simply does
    not need review — edits to it save live — and a pending article is
    already in the queue."""
    if _is_editor(request.user):
        article = get_object_or_404(Campaign, pk=article_id)
    else:
        article = get_object_or_404(Campaign, pk=article_id, author=request.user)

    if article.status == 'PUBLISHED':
        messages.success(request, 'This article is already published. Edits to it save live — no review is needed.')
        return redirect('campaigns:my_articles')
    if article.status == 'PENDING':
        messages.success(request, 'This article is already in review.')
        return redirect('campaigns:my_articles')
    if article.status not in ('DRAFT', 'REJECTED'):
        messages.error(request, 'Only draft articles can be submitted for review.')
        return redirect('campaigns:my_articles')

    if not (article.content_json or article.content) or (isinstance(article.content, str) and article.content.strip() == '<p><br></p>'):
        messages.error(request, 'Article body is empty. Add content before submitting.')
        return redirect('campaigns:edit_article', article_id=article.pk)

    if request.method == 'POST':
        article.status = 'PENDING'
        article.save(update_fields=['status'])
        messages.success(request, 'Article submitted for editorial review.')
        return redirect('campaigns:my_articles')

    return render(request, 'campaigns/submit_for_review.html', {'article': article})


# ─── IMAGE UPLOAD ENDPOINT (Editor.js) ────────────────────────────────────────

@login_required
@require_POST
def image_upload(request):
    """
    Editor.js image upload endpoint.
    Expects multipart/form-data with 'image' field.
    Returns: {"success": 1, "file": {"url": "<cloudinary_url>"}}
    """
    if not request.user.is_leader():
        return JsonResponse({'success': 0, 'error': 'Permission denied.'}, status=403)

    image_file = request.FILES.get('image')
    if not image_file:
        return JsonResponse({'success': 0, 'error': 'No image provided.'}, status=400)

    # 1. Validate File Size (Max 2MB for article body images)
    if image_file.size > 2 * 1024 * 1024:
        return JsonResponse({'success': 0, 'error': 'File size exceeds 2MB.'}, status=400)

    # 2. Validate File Extension
    import os
    ext = os.path.splitext(image_file.name)[1].lower()
    if ext not in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
        return JsonResponse({'success': 0, 'error': 'Invalid file extension.'}, status=400)

    # 3. Validate actual MIME type and Dimensions (do not trust client)
    try:
        from PIL import Image
        img = Image.open(image_file)
        img.verify()  # Verify it's actually an image
        
        # Check dimensions (optional limit, e.g., max 4000x4000)
        width, height = img.size
        if width > 4000 or height > 4000:
            return JsonResponse({'success': 0, 'error': 'Image dimensions too large. Max 4000x4000.'}, status=400)
            
        if img.format.lower() not in ['jpeg', 'png', 'gif', 'webp', 'jpg']:
            return JsonResponse({'success': 0, 'error': 'Invalid image format.'}, status=400)
    except Exception:
        return JsonResponse({'success': 0, 'error': 'Invalid or corrupted image file.'}, status=400)

    # Reset file pointer after PIL verification
    image_file.seek(0)

    try:
        import cloudinary.uploader
        result = cloudinary.uploader.upload(
            image_file,
            folder='kpn_newsroom/',
            resource_type='image',
        )
        return JsonResponse({
            'success': 1,
            'file': {'url': result.get('secure_url', '')},
        })
    except Exception as exc:
        return JsonResponse({'success': 0, 'error': str(exc)}, status=500)


# ─── EDITOR / REVIEW VIEWS ─────────────────────────────────────────────────────

@login_required
def review_queue(request):
    """Editorial review queue — visible to Media Director roles."""
    if not request.user.is_leader() or request.user.status != 'VERIFIED':
        messages.error(request, 'Access denied.')
        return redirect('staff:dashboard')

    role_title = getattr(request.user.role_definition, 'title', '')
    if role_title not in EDITOR_ROLES:
        messages.error(request, 'Only editors can access the review queue.')
        return redirect('staff:dashboard')

    pending = Campaign.objects.filter(status='PENDING').select_related(
        'author', 'lga'
    ).order_by('-updated_at')

    context = {'pending': pending}
    return render(request, 'campaigns/review_queue.html', context)


@login_required
def publish_article(request, article_id):
    """Publish an article from the review queue."""
    article = get_object_or_404(Campaign, pk=article_id)
    role_title = getattr(request.user.role_definition, 'title', '')
    if role_title not in EDITOR_ROLES:
        messages.error(request, 'Permission denied.')
        return redirect('staff:dashboard')

    if article.status != 'PENDING':
        messages.error(request, 'Only pending articles can be published.')
        return redirect('campaigns:review_queue')

    if request.method == 'POST':
        # Single publishing service (Phase 1): allocates the permanent
        # Story ID inside the same transaction; on failure the article
        # stays PENDING and recoverable.
        from .services import publish_campaign
        from story_intelligence.services import ConsentRequiredError
        try:
            publish_campaign(article, request.user)
        except ConsentRequiredError as exc:
            # Phase 4 consent guard: show the editor the exact reason
            # (e.g. a Human Impact story with no consent on file).
            messages.error(request, str(exc))
            return redirect('campaigns:review_queue')
        except Exception:
            messages.error(
                request,
                'Publishing failed and nothing was changed. The article is '
                'still in the review queue — please try again.')
            return redirect('campaigns:review_queue')
        messages.success(request, f'"{article.title}" is now published.')
        return redirect('campaigns:review_queue')

    return render(request, 'campaigns/publish_confirm.html', {'article': article})


@login_required
def return_article(request, article_id):
    """Return an article for revision with an editor note."""
    article = get_object_or_404(Campaign, pk=article_id)
    role_title = getattr(request.user.role_definition, 'title', '')
    if role_title not in EDITOR_ROLES:
        messages.error(request, 'Permission denied.')
        return redirect('staff:dashboard')

    if article.status != 'PENDING':
        messages.error(request, 'Only pending articles can be returned.')
        return redirect('campaigns:review_queue')

    if request.method == 'POST':
        note = request.POST.get('rejection_note', '').strip()
        article.status = 'REJECTED'
        article.rejection_note = note
        article.save(update_fields=['status', 'rejection_note'])
        messages.success(request, f'Article returned to {article.author.get_full_name()} for revision.')
        return redirect('campaigns:review_queue')

    return render(request, 'campaigns/return_article.html', {'article': article})


# ─── AJAX HELPER ──────────────────────────────────────────────────────────────

@login_required
def get_wards_for_lga(request):
    """AJAX: return ward list for a given LGA ID (used by write_article form)."""
    lga_id = request.GET.get('lga_id')
    try:
        wards = list(
            Ward.objects.filter(lga_id=lga_id).order_by('name').values('id', 'name')
        )
        return JsonResponse({'wards': wards})
    except Exception:
        return JsonResponse({'wards': []})


# ─── LEGACY ALIASES (keep old URL names working) ───────────────────────────────
create_campaign = write_article
my_campaigns = my_articles
edit_campaign = edit_article
delete_campaign = delete_article
submit_for_approval = submit_for_review
approval_queue = review_queue
approve_campaign = publish_article
reject_campaign = return_article
view_campaign = article_detail
all_campaigns = newsroom
